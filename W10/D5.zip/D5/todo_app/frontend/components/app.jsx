import React from 'react';
import TodoList from './todos/todo_list';
import TodoListContainer from './todos/todo_list_container'



const App = () => {
    return (
        <TodoListContainer />
    );
};

export default App;