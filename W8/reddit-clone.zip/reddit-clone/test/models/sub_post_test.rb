require 'test_helper'

class SubPostTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
