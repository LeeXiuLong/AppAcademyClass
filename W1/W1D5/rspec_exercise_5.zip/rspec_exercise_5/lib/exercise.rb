def zip(*arrays)
    results = Array.new(arrays[0].length) { Array.new() }
    
    arrays.each_with_index do |subarray, idx| 
        subarray.each_with_index do |ele, idx2|
            results[idx2] << ele
        end
    end
    results
end

def prizz_proc(arr, prc1, prc2)
    results = []
    arr.each { |ele| results << ele if prc1.call(ele) != prc2.call(ele) }
    results
end

def zany_zip(*arrays)
  height = 0
  
  arrays.each do |array|
    height = array.length if array.length > height
  end
  
  return_array = []
  (0...height).each {|num| return_array << []}

  arrays.each do |array|
    (0...height).each {|i| return_array[i] << array[i]}
  end

  return_array
end

def maximum(arr, &prc)

    return nil if arr.length == 0

    return_value = arr[0]

    arr.each do |ele|
        return_value = ele if prc.call(ele) >= prc.call(return_value)
    end
    
    return_value

end

def my_group_by(arr, &prc)
    hash = {}
    arr.each do |ele|
        if hash.has_key?(prc.call(ele))
             hash[prc.call(ele)] << ele 
        else
            hash[prc.call(ele)] = [ele]
        end
    end
    hash
end

def max_tie_breaker(arr, prc, &blk)

    return nil if arr.length == 0

    current_greatest = ""
    
    arr.each do |ele|
        if blk.call(ele) > blk.call(current_greatest)
            current_greatest = ele
        elsif blk.call(ele) == blk.call(current_greatest)
            if prc.call(ele) > prc.call(current_greatest)
                current_greatest = ele
            end
        end
    end
    current_greatest
end

def silly_syllables(sentence)
    results = []
    vowels = "aeiouAEIOU"
    words = sentence.split
    words.each do |word|
        vowel_count = 0
        word.each_char.with_index do |char, idx|
            vowel_count += 1 if vowels.include?(char)
        end
        if vowel_count < 2
            results << word 
        else
            results << modified_word(word)
        end
    end
    results.join(" ")
end

def modified_word(word)
    vowels = "aeiouAEIOU"
    first_position = nil
    last_position = nil
    word.each_char.with_index do |char, idx|
        if first_position == nil && vowels.include?(char)
            first_position = idx
            break
        end
    end
    i = word.length - 1
    while i >= 0
        if last_position == nil && vowels.include?(word[i])
            last_position = i
            break
        end
        i -= 1
    end
    word[first_position..last_position]
end