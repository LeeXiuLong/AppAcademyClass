def partition(arr, num)
    final = []
    ar1 = []
    ar2 = []
    arr.each do |ele|
        if ele < num
            ar1 << ele
        else
            ar2 << ele
        end
    end
    final.push(ar1,ar2)
    final
end

def merge(hash1, hash2)
    newHash = {}
    hash1.each do |key, val|
        newHash[key] = val
    end
    hash2.each do |key, val|
        newHash[key] = val
    end
    newHash
end

def censor(sent_str, arr)
    parts = sent_str.split(" ")
    parts.each do |ele|
        if arr.include?(ele.downcase)
            beep(ele)
        end
    end
    parts.join(" ")
end

def beep(word)
    vowels = "aeiouAIEOU"
    word.each_char.with_index do |char, idx|
        if vowels.include?(char)
            word[idx] = '*'
        end
    end
    word
end

def power_of_two?(num)
    (0...num).each do |i|
        if 2 ** i == num
            return true
        end
    end
    false
end


