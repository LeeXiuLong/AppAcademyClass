def palindrome?(str)
    beg = 0
    last = str.length - 1
    while beg < last
        return false if str[beg] != str[last]
        beg += 1
        last -= 1
    end
    return true
end

def substrings(str)
    i = 0
    newArr = []
    while i <= str.length-1
        j = i
        while j <= str.length-1
            substring = str[i..j]
            if newArr.include?(substring)
                j += 1
                next
            else
                newArr << str[i..j]
            end
            j += 1
        end
        i+=1
    end
    newArr
end

def palindrome_substrings(str)
    subs = substrings(str)
    final = []
    subs.each do |ele|
        if ele.length > 1 && palindrome?(ele)
            final << ele
        end
    end
    final
end

