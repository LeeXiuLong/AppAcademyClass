def tribonacci_number(num)
    arr = [1,1,2]
    if num == 1
        return 1
    elsif num == 2
        return 1
    elsif num == 3
        return 2
    else
        i = 3
        while i < num
            arr << arr[-1] + arr[-2] + arr[-3]
            i += 1
        end
    end
    arr[-1]
end

p tribonacci_number(1)  # 1
p tribonacci_number(2)  # 1
p tribonacci_number(3)  # 2
p tribonacci_number(4)  # 4
p tribonacci_number(5)  # 7
p tribonacci_number(6)  # 13
p tribonacci_number(7)  # 24
p tribonacci_number(11) # 274