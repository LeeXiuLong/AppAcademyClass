def pair_product(arr, num)
    i = 0
    while i < arr.length-1
        j = i+1
        while j <= arr.length - 1
            if arr[i] * arr[j] == num
                return true
            end
            j += 1
        end
        i+=1
    end
    false
end

p pair_product([4, 2, 5, 8], 16)    # true
p pair_product([8, 1, 9, 3], 8)     # true
p pair_product([3, 4], 12)          # true
p pair_product([3, 4, 6, 2, 5], 12) # true
p pair_product([4, 2, 5, 7], 16)    # false
p pair_product([8, 4, 9, 3], 8)     # false
p pair_product([3], 12)             # false