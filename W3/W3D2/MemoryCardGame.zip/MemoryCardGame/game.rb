require_relative "board"
require_relative "card"

class Game

    def initialize(board_size)
        @board = Board.new(board_size)
        @deck = self.create_deck
        @previous_guess = nil
    end

    def create_deck
        deck = []
        symbols = [:A, :K, :Q, :J, 10, 9 , 8, 7, 6, 5, 4, 3, 2]
        (0...@board.grid.flatten.length/2).each do |index|
            2.times { deck << Card.new(symbols[index])}
        end
        deck
    end

    def make_guess
        p "Please make a guess in the format of col row"
        guess = gets.chomp
        pos = guess.split
        pos
    end

    def play_game
        @board.populate(@deck)
        first_guess = true
        while !@board.won?
            @board.render
            pos = self.make_guess
            guess = @board.guess_pos(pos)
            if first_guess
                p "Your first guess is: #{guess}"
                @previous_guess = guess
                first_guess = false
                next
            end    
            if guess == @previous_guess
                p "Correct you found a match!" 
                @previous_guess = nil
            else
                p "incorrect guess"
                @previous_guess.hide
                @guess.hide
            end
            @first_guess = true
        end
    end




end